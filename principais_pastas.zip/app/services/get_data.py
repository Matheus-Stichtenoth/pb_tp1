#Pega Dados
import requests
import pandas as pd

def get_bcb_data (file_path):

    response = requests.get(file_path)

    # Verificando se a solicitação foi bem-sucedida
    if response.status_code == 200:
        # Convertendo a resposta JSON em um dicionário
        data = response.json()

        # Extraindo os dados desejados
        df = pd.json_normalize(data['value'])

        # Exibindo o DataFrame
    else:
        print(f"Erro na solicitação: {response.status_code}")

    return df.dropna()

#A função abaixo tem como objetivo mapear as microregiões através dos dois números iniciais do CEP
#Usar a seguinte syntax: df_bcb['Microregião'] = df_bcb['subregiao'].apply(get_microregion)
def get_microregion(cep_prefix):
    mapping = {
        '01': 'Grande São Paulo',
        '02': 'Grande São Paulo',
        '03': 'Interior de São Paulo',
        '04': 'Interior de São Paulo',
        '05': 'Litoral de São Paulo',
        '06': 'Litoral de São Paulo',
        '07': 'Rio de Janeiro e Espírito Santo',
        '08': 'Rio de Janeiro e Espírito Santo',
        '09': 'Rio de Janeiro e Espírito Santo',
        '10': 'Minas Gerais',
        '11': 'Minas Gerais',
        '12': 'Minas Gerais',
        '13': 'Minas Gerais',
        '14': 'Minas Gerais',
        '15': 'Minas Gerais',
        '16': 'Minas Gerais',
        '17': 'Minas Gerais',
        '18': 'Minas Gerais',
        '19': 'Minas Gerais',
        '20': 'Rio de Janeiro',
        '21': 'Rio de Janeiro',
        '22': 'Rio de Janeiro',
        '23': 'Rio de Janeiro',
        '24': 'Rio de Janeiro',
        '25': 'Rio de Janeiro',
        '26': 'Rio de Janeiro',
        '27': 'Rio de Janeiro',
        '28': 'Rio de Janeiro',
        '29': 'Bahia - Salvador e Região Metropolitana',
        '30': 'Bahia - Salvador e Região Metropolitana',
        '31': 'Minas Gerais - Belo Horizonte e Região Metropolitana',
        '32': 'Minas Gerais - Belo Horizonte e Região Metropolitana',
        '33': 'Minas Gerais - Belo Horizonte e Região Metropolitana',
        '34': 'Minas Gerais - Triângulo Mineiro',
        '35': 'Minas Gerais - Triângulo Mineiro',
        '36': 'Minas Gerais - Zona da Mata e outras regiões',
        '37': 'Minas Gerais - Zona da Mata e outras regiões',
        '38': 'Minas Gerais - Zona da Mata e outras regiões',
        '39': 'Minas Gerais - Zona da Mata e outras regiões',
        '40': 'Bahia - Interior e outras regiões',
        '41': 'Bahia - Interior e outras regiões',
        '42': 'Bahia - Interior e outras regiões',
        '43': 'Bahia - Interior e outras regiões',
        '44': 'Bahia - Interior e outras regiões',
        '45': 'Sergipe',
        '46': 'Sergipe',
        '47': 'Sergipe',
        '48': 'Sergipe',
        '49': 'Sergipe',
        '50': 'Pernambuco - Recife e Região Metropolitana',
        '51': 'Pernambuco - Recife e Região Metropolitana',
        '52': 'Pernambuco - Recife e Região Metropolitana',
        '53': 'Pernambuco - Interior',
        '54': 'Pernambuco - Interior',
        '55': 'Pernambuco - Interior',
        '56': 'Pernambuco - Interior',
        '57': 'Alagoas',
        '58': 'Alagoas',
        '59': 'Alagoas',
        '60': 'Ceará - Fortaleza e Região Metropolitana',
        '61': 'Ceará - Fortaleza e Região Metropolitana',
        '62': 'Ceará - Fortaleza e Região Metropolitana',
        '63': 'Ceará - Fortaleza e Região Metropolitana',
        '64': 'Ceará - Interior',
        '65': 'Maranhão',
        '66': 'Maranhão',
        '67': 'Pará',
        '68': 'Pará',
        '69': 'Amazonas',
        '70': 'Distrito Federal e Goiás - Brasília e entorno',
        '71': 'Distrito Federal e Goiás - Brasília e entorno',
        '72': 'Distrito Federal e Goiás - Brasília e entorno',
        '73': 'Goiás',
        '74': 'Goiás',
        '75': 'Tocantins',
        '76': 'Tocantins',
        '77': 'Tocantins',
        '78': 'Mato Grosso',
        '79': 'Mato Grosso',
        '80': 'Paraná',
        '81': 'Paraná',
        '82': 'Paraná',
        '83': 'Paraná',
        '84': 'Santa Catarina',
        '85': 'Santa Catarina',
        '86': 'Rio Grande do Sul',
        '87': 'Rio Grande do Sul',
        '88': 'Rio Grande do Sul',
        '89': 'Rio Grande do Sul',
        '90': 'Porto Alegre e Região Metropolitana',
        '91': 'Porto Alegre e Região Metropolitana',
        '92': 'Porto Alegre e Região Metropolitana',
        '93': 'Porto Alegre e Região Metropolitana',
        '94': 'Porto Alegre e Região Metropolitana',
        '95': 'Serra Gaúcha',
        '96': 'Interior do Rio Grande do Sul',
        '97': 'Interior do Rio Grande do Sul',
        '98': 'Interior do Rio Grande do Sul',
        '99': 'Interior do Rio Grande do Sul',
        'NI': 'Não Identificado'
    }
    
    return mapping.get(cep_prefix, 'Não Identificado')

file_path_bcb = 